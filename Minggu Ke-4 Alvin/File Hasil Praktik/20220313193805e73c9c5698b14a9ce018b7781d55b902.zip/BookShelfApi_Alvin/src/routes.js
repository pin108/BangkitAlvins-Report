const {
  AddbookHandler, GetBookHandler, getBookByIdHandler,
  editBookByIdHandler, deleteBookByIdHandler,
} = require('./handler');
// Method Add, Delete, Edit, and Get Data
const routes = [
  {
    method: 'POST',
    path: '/books',
    handler: AddbookHandler,
  },

  {
    method: 'GET',
    path: '/books',
    handler: GetBookHandler,
  },

  {
    method: 'PUT',
    path: '/books/{bookId}',
    handler: editBookByIdHandler,
  },

  {
    method: 'DELETE',
    path: '/books/{bookId}',
    handler: deleteBookByIdHandler,
  },

  {
    method: 'GET',
    path: '/books/{bookId}',
    handler: getBookByIdHandler,
  },
];

module.exports = routes;
